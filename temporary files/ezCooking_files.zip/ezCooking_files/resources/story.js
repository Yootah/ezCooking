var story = {
 "pages": [
  {
   "image": "StartPage_News.png",
   "image2x": "StartPage_News@2x.png",
   "width": 1002,
   "links": [
    {
     "rect": [
      680,
      57,
      748,
      84
     ],
     "page": 2
    },
    {
     "rect": [
      748,
      57,
      832,
      84
     ],
     "page": 6
    },
    {
     "rect": [
      45,
      83,
      96,
      110
     ],
     "page": 2
    },
    {
     "rect": [
      96,
      83,
      174,
      110
     ],
     "page": 6
    }
   ],
   "title": "StartPage_News",
   "height": 517
  },
  {
   "image": "StartPage_Subs.png",
   "image2x": "StartPage_Subs@2x.png",
   "width": 1004,
   "links": [
    {
     "rect": [
      12,
      87,
      62,
      114
     ],
     "page": 0
    },
    {
     "rect": [
      62,
      87,
      147,
      114
     ],
     "page": 4
    },
    {
     "rect": [
      131,
      354,
      199,
      381
     ],
     "page": 2
    },
    {
     "rect": [
      199,
      354,
      283,
      381
     ],
     "page": 7
    },
    {
     "rect": [
      0,
      0,
      479,
      80
     ],
     "page": 0
    },
    {
     "rect": [
      5,
      151,
      436,
      184
     ],
     "page": 8
    }
   ],
   "title": "StartPage_Subs",
   "height": 520
  },
  {
   "image": "AllRecipesPage_Default.png",
   "image2x": "AllRecipesPage_Default@2x.png",
   "width": 988,
   "links": [
    {
     "rect": [
      105,
      871,
      172,
      898
     ],
     "page": 0
    },
    {
     "rect": [
      867,
      86,
      975,
      114
     ],
     "page": 9
    },
    {
     "rect": [
      19,
      327,
      960,
      368
     ],
     "page": 8
    },
    {
     "rect": [
      0,
      0,
      479,
      80
     ],
     "page": 0
    }
   ],
   "title": "AllRecipesPage_Default",
   "height": 941
  },
  {
   "image": "One Way - Itinerary.png",
   "image2x": "One Way - Itinerary@2x.png",
   "width": 985,
   "links": [],
   "title": "One Way - Itinerary",
   "height": 955
  },
  {
   "image": "StartPage_NewsRecipes.png",
   "image2x": "StartPage_NewsRecipes@2x.png",
   "width": 1004,
   "links": [
    {
     "rect": [
      12,
      87,
      62,
      114
     ],
     "page": 0
    },
    {
     "rect": [
      147,
      87,
      234,
      114
     ],
     "page": 1
    },
    {
     "rect": [
      680,
      60,
      748,
      87
     ],
     "page": 2
    },
    {
     "rect": [
      748,
      60,
      832,
      87
     ],
     "page": 5
    },
    {
     "rect": [
      0,
      0,
      479,
      80
     ],
     "page": 0
    },
    {
     "rect": [
      5,
      151,
      436,
      184
     ],
     "page": 8
    }
   ],
   "title": "StartPage_NewsRecipes",
   "height": 520
  },
  {
   "image": "StartPage_NewsRecipesLoginError.png",
   "image2x": "StartPage_NewsRecipesLoginError@2x.png",
   "width": 1002,
   "links": [{
    "rect": [
     646,
     369,
     726,
     393
    ],
    "page": 4
   }],
   "title": "StartPage_NewsRecipesLoginError",
   "height": 517
  },
  {
   "image": "StartPage_NewsLoginError.png",
   "image2x": "StartPage_NewsLoginError@2x.png",
   "width": 1002,
   "links": [
    {
     "rect": [
      646,
      369,
      726,
      393
     ],
     "page": 0
    },
    {
     "rect": [
      743,
      366,
      823,
      396
     ],
     "page": 11
    }
   ],
   "title": "StartPage_NewsLoginError",
   "height": 517
  },
  {
   "image": "StartPage_SubsLoginError.png",
   "image2x": "StartPage_SubsLoginError@2x.png",
   "width": 1002,
   "links": [{
    "rect": [
     646,
     369,
     726,
     393
    ],
    "page": 1
   }],
   "title": "StartPage_SubsLoginError",
   "height": 517
  },
  {
   "image": "RecipeSelected.png",
   "image2x": "RecipeSelected@2x.png",
   "width": 986,
   "links": [
    {
     "rect": [
      103,
      871,
      170,
      898
     ],
     "page": 0
    },
    {
     "rect": [
      227,
      871,
      295,
      898
     ],
     "page": 2
    },
    {
     "rect": [
      865,
      86,
      973,
      114
     ],
     "page": 9
    },
    {
     "rect": [
      0,
      0,
      479,
      80
     ],
     "page": 0
    }
   ],
   "title": "RecipeSelected",
   "height": 941
  },
  {
   "image": "AllRecipesPage_Default_AdvancedSearch.png",
   "image2x": "AllRecipesPage_Default_AdvancedSearch@2x.png",
   "width": 986,
   "links": [
    {
     "rect": [
      871,
      327,
      969,
      360
     ],
     "page": 10
    },
    {
     "rect": [
      103,
      871,
      170,
      898
     ],
     "page": 0
    },
    {
     "rect": [
      227,
      871,
      295,
      898
     ],
     "page": 2
    },
    {
     "rect": [
      10,
      407,
      951,
      448
     ],
     "page": 8
    },
    {
     "rect": [
      0,
      0,
      479,
      80
     ],
     "page": 0
    }
   ],
   "title": "AllRecipesPage_Default_AdvancedSearch",
   "height": 941
  },
  {
   "image": "AllRecipesPage_Default_Sorted.png",
   "image2x": "AllRecipesPage_Default_Sorted@2x.png",
   "width": 986,
   "links": [
    {
     "rect": [
      103,
      871,
      170,
      898
     ],
     "page": 0
    },
    {
     "rect": [
      227,
      871,
      295,
      898
     ],
     "page": 2
    },
    {
     "rect": [
      865,
      86,
      973,
      114
     ],
     "page": 9
    },
    {
     "rect": [
      17,
      407,
      953,
      448
     ],
     "page": 8
    },
    {
     "rect": [
      0,
      0,
      479,
      80
     ],
     "page": 0
    }
   ],
   "title": "AllRecipesPage_Default_Sorted",
   "height": 941
  },
  {
   "image": "LoginScreen_Default.png",
   "image2x": "LoginScreen_Default@2x.png",
   "width": 982,
   "links": [
    {
     "rect": [
      608,
      279,
      688,
      309
     ],
     "page": 12
    },
    {
     "rect": [
      1,
      0,
      480,
      80
     ],
     "page": 0
    },
    {
     "rect": [
      229,
      279,
      309,
      309
     ],
     "page": 13
    },
    {
     "rect": [
      704,
      279,
      785,
      309
     ],
     "page": 0
    },
    {
     "rect": [
      624,
      56,
      692,
      83
     ],
     "page": 2
    },
    {
     "rect": [
      692,
      56,
      776,
      83
     ],
     "page": 6
    }
   ],
   "title": "LoginScreen_Default",
   "height": 516
  },
  {
   "image": "LoginScreen_Failed.png",
   "image2x": "LoginScreen_Failed@2x.png",
   "width": 982,
   "links": [
    {
     "rect": [
      0,
      0,
      479,
      80
     ],
     "page": 0
    },
    {
     "rect": [
      704,
      279,
      785,
      309
     ],
     "page": 0
    },
    {
     "rect": [
      624,
      56,
      692,
      83
     ],
     "page": 2
    },
    {
     "rect": [
      692,
      56,
      776,
      83
     ],
     "page": 6
    },
    {
     "rect": [
      229,
      279,
      309,
      309
     ],
     "page": 13
    }
   ],
   "title": "LoginScreen_Failed",
   "height": 516
  },
  {
   "image": "LoginScreen_Register.png",
   "image2x": "LoginScreen_Register@2x.png",
   "width": 982,
   "links": [
    {
     "rect": [
      1,
      0,
      480,
      80
     ],
     "page": 0
    },
    {
     "rect": [
      624,
      56,
      692,
      83
     ],
     "page": 2
    },
    {
     "rect": [
      692,
      56,
      776,
      83
     ],
     "page": 6
    },
    {
     "rect": [
      704,
      423,
      784,
      453
     ],
     "page": 14
    }
   ],
   "title": "LoginScreen_Register",
   "height": 516
  },
  {
   "image": "LoginScreen_DefaultCorrectInput.png",
   "image2x": "LoginScreen_DefaultCorrectInput@2x.png",
   "width": 982,
   "links": [
    {
     "rect": [
      91,
      407,
      158,
      434
     ],
     "page": 0
    },
    {
     "rect": [
      215,
      407,
      283,
      434
     ],
     "page": 2
    },
    {
     "rect": [
      608,
      279,
      688,
      309
     ],
     "page": 15
    },
    {
     "rect": [
      1,
      0,
      480,
      80
     ],
     "page": 0
    },
    {
     "rect": [
      229,
      279,
      309,
      309
     ],
     "page": 13
    },
    {
     "rect": [
      704,
      279,
      785,
      309
     ],
     "page": 0
    },
    {
     "rect": [
      624,
      56,
      692,
      83
     ],
     "page": 2
    },
    {
     "rect": [
      692,
      56,
      776,
      83
     ],
     "page": 6
    }
   ],
   "title": "LoginScreen_DefaultCorrectInput",
   "height": 516
  },
  {
   "image": "StartPage_NewsLoggedIn.png",
   "image2x": "StartPage_NewsLoggedIn@2x.png",
   "width": 1002,
   "links": [
    {
     "rect": [
      748,
      57,
      832,
      84
     ],
     "page": 6
    },
    {
     "rect": [
      832,
      57,
      884,
      84
     ],
     "page": 0
    }
   ],
   "title": "StartPage_NewsLoggedIn",
   "height": 517
  }
 ],
 "resolutions": [2],
 "title": "ezCooking",
 "highlightLinks": true
}